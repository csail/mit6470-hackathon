(function() {

  window.AA = {};

}).call(this);
